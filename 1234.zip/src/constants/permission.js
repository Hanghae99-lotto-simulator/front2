export const PERMISSION_ALL = 0;
